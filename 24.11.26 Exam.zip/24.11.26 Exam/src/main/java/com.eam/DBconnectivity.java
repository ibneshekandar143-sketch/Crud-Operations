public class DBConnectivity {

    Connection con;

    public Connection connect_to_db() {
        String url = "jdbc:postgresql://localhost:5432/employee_db";
        String username = "postgres";
        String password = "postgres";
        try {
//            Class.forName("org.postgresql.Driver");//Loading Driver
            con = DriverManager.getConnection(url, username, password);
            if (con != null) {
                System.out.println("Database connected.");
            } else {
                System.out.println("Connection failed");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return con;
    }

}