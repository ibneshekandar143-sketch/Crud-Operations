public class Employee implements Serializable {

    private int empid;
    private String name;
    private String email;
    private String designation;
    private String department;
    private double salary;
    private Date hireDate;

    Employee() {

    }

    public int getEmpid() {
        return empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public Date getHireDate() {
        return hireDate;
    }

    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }

    private boolean editMode = false;

    public boolean getEditMode() {
        return editMode;
    }

    public void setEditMode(boolean editMode) {
        this.editMode = editMode;
    }

    public List<Employee> getAllEmployees() {
        DBConnectivity dbc = new DBConnectivity();
        ArrayList<Employee> employees = new ArrayList<>();
        Connection con = dbc.connect_to_db();
        PreparedStatement pst;
        try {
            pst = con.prepareStatement("select * from employee");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Employee emp = new Employee();
                emp.setEmpid(rs.getInt("empid"));
                emp.setName(rs.getString("name"));
                emp.setEmail(rs.getString("email"));
                emp.setDesignation(rs.getString("designation"));
                emp.setDepartment(rs.getString("department"));
                emp.setHireDate(rs.getDate("hire_date"));
                emp.setSalary(rs.getDouble("salary"));
                employees.add(emp);
            }
        } catch (SQLException ex) {
            System.getLogger(Employee.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
        return employees;
    }

    public String addEmployee() {
        DBConnectivity dbc = new DBConnectivity();
        Connection con = dbc.connect_to_db();

        String sql = "INSERT INTO employee (name, email, designation, department, salary, hire_date) VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, name);
            pst.setString(2, email);
            pst.setString(3, designation);
            pst.setString(4, department);
            pst.setDouble(5, salary);

            if (hireDate != null) {
                pst.setDate(6, new java.sql.Date(hireDate.getTime()));
            } else {
                pst.setNull(6, java.sql.Types.DATE);
            }

            pst.executeUpdate();
            clearForm();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        // ✅ REDIRECT
        return "index?faces-redirect=true";
    }

    public void editEmployee(Employee emp) {
        this.empid = emp.empid;
        this.name = emp.name;
        this.email = emp.email;
        this.designation = emp.designation;
        this.department = emp.department;
        this.salary = emp.salary;
        this.hireDate = emp.hireDate;

        this.editMode = true;
    }

    public String updateEmployee() {
        DBConnectivity dbc = new DBConnectivity();
        Connection con = dbc.connect_to_db();

        String sql = "UPDATE employee SET name=?, email=?, designation=?, department=?, salary=?, hire_date=? WHERE empid=?";

        try (PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, name);
            pst.setString(2, email);
            pst.setString(3, designation);
            pst.setString(4, department);
            pst.setDouble(5, salary);
            pst.setDate(6, new java.sql.Date(hireDate.getTime()));
            pst.setInt(7, empid);

            pst.executeUpdate();
            clearForm();
            editMode = false;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        // REDIRECT
        return "index?faces-redirect=true";
    }

    private void clearForm() {
        empid = 0;
        name = null;
        email = null;
        designation = null;
        department = null;
        salary = 0;
        hireDate = null;
    }

    public void deleteEmployee(Employee emp) {
        DBConnectivity dbc = new DBConnectivity();
        Connection con = dbc.connect_to_db();

        String sql = "DELETE FROM employee WHERE empid=?";

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, emp.getEmpid());
            pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}